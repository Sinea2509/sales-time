@echo off
setlocal
title Sales Time - lot 75 - nettoyage et verification

echo.
echo ============================================================
echo    SALES TIME - LOT 75
echo    Nettoyage des fichiers perimes, puis verification
echo ============================================================
echo.

rem ---------- 1. Sommes-nous dans le bon dossier ? ----------
if not exist "package.json" goto MAUVAIS_DOSSIER
if not exist "prisma\schema.prisma" goto MAUVAIS_DOSSIER
echo [1/4] Dossier du projet reconnu.

rem ---------- 2. Le lot 75 a-t-il bien ete depose ? ----------
if not exist "src\core\domain\profile-score-scale.ts" goto LOT_ABSENT
echo [2/4] Les fichiers du lot 75 sont bien la.
echo.

rem ---------- 3. Suppression des cinq fichiers perimes ----------
echo [3/4] Fichiers perimes :
call :SUPPRIME "components\organisms\meeting-matrix-scatter.tsx"
call :SUPPRIME "lib\meeting-outcome-badge-styles.ts"
call :SUPPRIME "lib\meeting-outcome-config.ts"
call :SUPPRIME "lib\meeting-outcome-labels.ts"
call :SUPPRIME "src\core\application\get-org-dashboard-kpis.ts"
echo.

rem ---------- 4. Verification ----------
echo [4/4] Verification du code. Compte une a trois minutes.
echo       Ne ferme pas cette fenetre.
echo.
echo       ... preparation de la base de donnees
call npx prisma generate
if errorlevel 1 goto ECHEC_PRISMA
echo.
echo       ... relecture de tout le code. C est le plus long.
call npx tsc --noEmit
if errorlevel 1 goto ECHEC_TSC

echo.
echo ============================================================
echo    TOUT EST VERT.
echo.
echo    Le code est propre et pret a partir en ligne.
echo    Reviens le dire a Claude, il te donne la suite.
echo ============================================================
echo.
pause
exit /b 0


rem ================= sous-programme =================
:SUPPRIME
if exist %1 (
  del /f /q %1
  echo       supprime : %~1
) else (
  echo       deja absent : %~1
)
exit /b 0


rem ================= messages d erreur =================
:MAUVAIS_DOSSIER
echo.
echo ############################################################
echo    CE FICHIER N EST PAS AU BON ENDROIT.
echo.
echo    Il doit etre pose a la racine de ton projet Sales Time,
echo    c est a dire dans le dossier ou se trouvent le fichier
echo    package.json et le dossier prisma.
echo.
echo    Deplace 3-verifier.bat a cet endroit, puis double-clique
echo    a nouveau dessus.
echo ############################################################
echo.
pause
exit /b 1

:LOT_ABSENT
echo.
echo ############################################################
echo    LE LOT 75 N A PAS ETE DEPOSE.
echo.
echo    Le dossier du projet est bien reconnu, mais le fichier
echo    src\core\domain\profile-score-scale.ts est introuvable.
echo.
echo    Reprends l etape 1 : dans le zip, ouvre 2-FICHIERS-A-COPIER,
echo    selectionne tout son contenu, et depose-le dans le
echo    dossier du projet en acceptant le remplacement.
echo ############################################################
echo.
pause
exit /b 1

:ECHEC_PRISMA
echo.
echo ############################################################
echo    LA PREPARATION DE LA BASE A ECHOUE.
echo.
echo    Cause la plus frequente : les dependances du projet ne
echo    sont pas installees sur cette machine.
echo.
echo    Ouvre PowerShell dans ce dossier, lance la commande
echo       npm install
echo    attends la fin, puis relance 3-verifier.bat.
echo.
echo    Si ca ne suffit pas, copie tout le texte de cette
echo    fenetre et colle-le a Claude.
echo ############################################################
echo.
pause
exit /b 1

:ECHEC_TSC
echo.
echo ############################################################
echo    IL RESTE DES ERREURS DANS LE CODE.
echo.
echo    La liste est affichee juste au dessus de ce cadre.
echo.
echo    N envoie rien en ligne pour l instant. Selectionne tout
echo    le texte de cette fenetre, copie-le, et colle-le a
echo    Claude. Il te dira quoi corriger.
echo ############################################################
echo.
pause
exit /b 1
