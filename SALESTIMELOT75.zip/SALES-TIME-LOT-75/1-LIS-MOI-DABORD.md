# Sales Time : ce que tu fais maintenant

Deux étapes seulement. On verra la suite après, quand celles-ci seront faites.

**Rien n'est risqué.** Ton site en ligne continue de tourner normalement pendant
toute l'opération. Tant que tu n'as pas envoyé le code sur GitHub, absolument
rien ne change pour tes utilisateurs. Et même après, si quelque chose se passait
mal, Vercel garde la version actuelle en ligne et refuse simplement de publier
la nouvelle.

## Ce que tu as sous la main

```
SALES-TIME-LOT-75\
   1-LIS-MOI-DABORD.md      <- ce fichier
   2-FICHIERS-A-COPIER\     <- etape 1
   3-verifier.bat           <- etape 2
   annexes\                 <- rien a faire, tu peux ignorer
```

Les numéros donnent l'ordre. Tu fais 1, puis 2, puis 3, et c'est tout.

## Étape 1 : déposer les nouveaux fichiers

Comme d'habitude. Ouvre le dossier `2-FICHIERS-A-COPIER`, sélectionne tout ce
qu'il y a dedans (`Ctrl + A`), et dépose-le dans ton dossier de projet Sales
Time, celui qui contient le fichier `package.json`.

Windows va te demander de confirmer le remplacement de plusieurs centaines de
fichiers. Réponds oui, remplacer les fichiers dans la destination.

Une précision pour éviter une mauvaise surprise : trois éléments de ce dossier
commencent par un point, `.cursor`, `.env.example` et `.env.production.example`.
Windows les cache par défaut, donc `Ctrl + A` ne les sélectionnera pas. Ce ne
sont que des fichiers d'explication, ils ne servent pas au fonctionnement du
site, tu peux très bien les laisser. Si tu veux quand même les copier : dans
l'explorateur, onglet **Affichage**, coche **Éléments masqués**, puis refais
`Ctrl + A`.

## Étape 2 : supprimer cinq fichiers

C'est la seule vraie nouveauté, et c'est important. Ces cinq fichiers ont été
remplacés par du code mieux organisé, mais une archive ne sait pas supprimer,
donc ils sont encore chez toi. Tant qu'ils sont là, la mise en ligne échouera.

Tu peux le faire de deux façons, au choix.

### Le plus simple : double-cliquer

Copie le fichier `3-verifier.bat` dans ton dossier de projet, celui qui contient
`package.json`. Double-clique dessus.

Il supprime les cinq fichiers, puis il relit tout le code pour confirmer qu'il
ne reste aucune erreur. Compte une à trois minutes. À la fin, il affiche soit
`TOUT EST VERT`, soit une liste d'erreurs.

Windows peut afficher un avertissement bleu du type « Windows a protégé votre
ordinateur ». C'est normal pour un fichier téléchargé. Clique sur
« Informations complémentaires », puis sur « Exécuter quand même ».

### À la main, si tu préfères

Va dans chacun de ces sous-dossiers de ton projet et supprime le fichier
indiqué :

| Ouvre ce dossier | Supprime ce fichier |
| --- | --- |
| `components\organisms` | `meeting-matrix-scatter.tsx` |
| `lib` | `meeting-outcome-badge-styles.ts` |
| `lib` | `meeting-outcome-config.ts` |
| `lib` | `meeting-outcome-labels.ts` |
| `src\core\application` | `get-org-dashboard-kpis.ts` |

Trois d'entre eux sont dans le même dossier `lib`, donc tu n'as que trois
dossiers à ouvrir en tout. Si l'un d'eux n'existe pas, tant mieux, passe au
suivant. Ce sont bien ces cinq-là et pas d'autres.

## Si quelque chose coince

Sélectionne tout le texte de la fenêtre noire, copie-le, et colle-le moi. Il n'y
a pas de mauvaise erreur : chacune me dit exactement quoi corriger.

## Le dossier annexes

Rien à faire avec, c'est juste rangé là si un jour tu es curieux.

`explication-technique.md` détaille ce que ce lot change dans le produit, notes
et calculs compris. `pour-plus-tard-deploiement-vercel.md` est la version
technique de la mise en ligne, écrite pour un développeur : tu n'en as pas
besoin, je te donnerai les mêmes étapes en clair le moment venu.
`sales-time-lot75.patch` est une copie de secours du code, utile seulement si un
jour on doit tout rejouer proprement.

## Ensuite

Dis-moi simplement « c'est fait » et je te donne les deux étapes suivantes,
celles qui envoient tout en ligne. Une chose à la fois.
