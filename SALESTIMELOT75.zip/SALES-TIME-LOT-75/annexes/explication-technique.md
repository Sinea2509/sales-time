# Sales Time, lot 75 : les notes SONCAS et DISC sont calibrées

## Ce qui change, en une phrase

SONCAS et DISC demandaient au modèle une note de 0 à 100 sans jamais lui dire
ce que valait un 40 ni un 80. Ils reçoivent maintenant la même échelle ancrée
que le score de coaching, et un levier SONCAS annoncé haut sans une citation
pour le tenir est corrigé par le produit avant d'être enregistré.

## À lire avant de déployer

Le SalesScore d'un rendez-vous est la moyenne des six leviers SONCAS
(`salesScoreFromSoncasResult`, un simple `Math.round(somme / 6)`). Calibrer
SONCAS déplace donc **tous les SalesScore, toutes les moyennes de commercial et
toutes les places au classement de l'équipe**.

C'est l'effet recherché : aujourd'hui les notes flottent vers le haut et le
classement départage des chiffres qui ne veulent pas dire grand-chose. Mais
c'est un changement visible. Un manager qui ouvre son tableau après le
déploiement verra bouger des chiffres que personne n'a touchés à la main, et il
vaut mieux qu'il l'apprenne de toi que de son tableau.

Deux précisions qui comptent pour la conversation que tu auras avec lui :

Les analyses **déjà en base ne bougent pas**. La correction s'applique à
l'écriture, jamais à la lecture. Un rendez-vous analysé avant le déploiement
garde exactement les notes qu'il annonçait. Ce sont les nouvelles analyses qui
descendront, et la moyenne du commercial glissera donc au fil des semaines
plutôt que d'un coup.

Les notes vont **baisser en moyenne**, pas monter. L'échelle demande de trancher
vers le bas en cas de doute, et le verbatim obligatoire retire les points posés
sans preuve. Un commercial dont le SalesScore descend de 72 à 58 n'est pas moins
bon qu'avant : il est mesuré pour la première fois.

## L'échelle, en clair

Cinq crans, les mêmes pour les six leviers SONCAS et les quatre styles DISC.
Chaque cran se décrit par ce qu'on peut citer du compte rendu, jamais par une
appréciation :

| Note | Ce qu'il faut avoir entendu |
| --- | --- |
| 0 à 19 | rien dans le compte rendu ne le montre, ou rien de citable |
| 20 à 39 | un signe isolé, ou un signe qui se lirait aussi bien autrement |
| 40 à 59 | ça se voit clairement au moins une fois, dans les mots du prospect |
| 60 à 79 | ça revient à plusieurs moments distincts du rendez-vous |
| 80 à 100 | ça traverse tout le rendez-vous et façonne ce que le prospect demande |

Et la règle du doute, celle du score de coaching : entre deux crans, prendre
celui du dessous.

## Le verbatim obligatoire

C'est devenu une règle du produit, plus seulement une consigne au modèle.

Un levier SONCAS annoncé au-dessus de 19 avec une liste `evidence` vide
redescend à 19 avant l'enregistrement. Il redescend sans tomber à zéro : ce
qu'on sait, c'est que la preuve manque, pas que le levier est absent. Le levier
dominant est recalculé dès qu'une note a bougé, sans quoi la fiche annoncerait
« dominant : Argent » au-dessus d'un Argent que le produit vient justement de
retirer.

Le journal d'appel, lui, garde ce que le modèle a réellement rendu. C'est la
seule trace où l'on puisse constater qu'un levier avait été annoncé à 80 sans
une seule citation pour le tenir, et c'est exactement ce qu'on ira relire le
jour où une note surprendra.

**DISC n'a volontairement pas de règle équivalente.** Son schéma porte une seule
liste `evidence` pour ses quatre styles : aucune preuve n'y est rattachable à
une note en particulier, si bien qu'une règle automatique jetterait les quatre
notes dès que la liste est vide, ou n'en jetterait aucune. Les deux seraient
faux. DISC s'en remet à sa consigne, qui réclame des preuves nommant le style
qu'elles appuient. Un test vérifie d'ailleurs que la consigne DISC ne promet
pas une correction qui ne tourne pas.

## Ce qu'il y a dans l'archive

Le dossier `sales-time/` contient les 345 fichiers ajoutés ou modifiés depuis
`42f29fc`, à recopier par-dessus le dépôt. `sales-time-lot75.patch` est la même
chose sous forme de série de 75 commits, si tu préfères `git am`.

Dix fichiers sont touchés par ce lot précis :

- `src/core/domain/profile-score-scale.ts` (nouveau), l'échelle et les deux
  consignes de calibration
- `src/core/domain/soncas-evidence-rule.ts` (nouveau), la règle « pas de preuve,
  pas de note »
- `lib/ai-system-prompt.ts`, deux nouveaux enrobages `withSoncasSystemPrompt` et
  `withDiscSystemPrompt`
- `src/adapters/vercel/vercel-ai-analysis-adapter.ts`, qui les utilise pour
  SONCAS et DISC seulement
- `src/core/application/run-meeting-analysis.ts`, qui applique la règle après le
  journal et avant l'enregistrement
- les cinq fichiers de tests correspondants

## Avant de lancer le build

Deux migrations attendent depuis le lot 73 et le lot 74. Elles n'ont rien à voir
avec ce lot-ci, mais elles doivent passer :

```
npx prisma migrate deploy
npx prisma generate
npm run verify
npm run build
```

Je ne peux toujours pas produire le client Prisma dans le bac à sable, donc
`tsc` y reste à ses 100 erreurs habituelles et le seul test rouge est celui qui
importe le client généré. Chez toi, les deux doivent être propres.

## Vérifié de mon côté

160 suites et 1374 tests, avec pour seul échec `tests/company-features.actions.test.ts`,
déjà rouge avant ce lot faute du client Prisma. ESLint à zéro. cspell à 98
signalements, exactement comme au départ. Prettier propre sur tout le lot. Et
19 mutants passés sur les deux nouveaux modules, dont deux témoins volontairement
équivalents qui survivent comme prévu : sans eux, un taux de 100 % ne prouverait
rien du tout.

## La suite

Le déploiement Vercel, comme tu l'as demandé, avant la sécurité.

## Deux décisions qui t'attendent toujours

**Le SalesScore.** Il est la moyenne des six leviers SONCAS, c'est-à-dire une
mesure du **prospect**, pas du commercial. Un vendeur tombé sur un prospect
tiède obtient un SalesScore bas sans avoir rien fait de mal, et le classement de
l'équipe se retrouve à trier des vendeurs sur la personnalité de leurs clients.
KISS produit déjà un `sellerSkills` qui note, lui, ce que le commercial a fait.
Faut-il rebrancher le SalesScore dessus ? C'est un choix produit, pas technique,
et je ne le prendrai pas à ta place.

**La scorecard et KISS.** Sur un rendez-vous de découverte qui a une grille, on
affiche aujourd'hui les deux : les trois colonnes `keep` / `improve` / `stop` de
KISS et la scorecard. Soit la scorecard remplace le bloc KISS quand une grille
existe, soit les deux cohabitent. L'onglet « Fiche d'un RDV de découverte » de
l'aperçu HTML est là pour que tu tranches en regardant.
