# Sales Time : déployer sur Vercel

J'ai audité la configuration de déploiement avant d'écrire cette marche à
suivre. Bonne nouvelle d'abord : il n'y a **rien à créer et aucune variable
d'environnement à ajouter**. Mauvaise nouvelle ensuite : il y a **cinq fichiers
à supprimer**, et sans ça le build Vercel échoue.

## 1. Le point bloquant : cinq fichiers à supprimer

Depuis le début, je te livre des archives de fichiers *ajoutés ou modifiés*.
Une archive ne sait pas supprimer. Or, entre ta base `42f29fc` et aujourd'hui,
cinq fichiers ont disparu du projet, remplacés par du code mieux découpé. Ils
sont donc toujours chez toi, ils importent des fonctions qui n'existent plus, et
`next build` refuse de compiler avec des erreurs de type.

Je l'ai vérifié plutôt que supposé : je les ai remis dans mon dépôt, `tsc` est
passé de 100 erreurs à 104, et voici les quatre :

```
components/organisms/meeting-matrix-scatter.tsx(7,3)
  Module '@/lib/meeting-etape-pill' has no exported member
  'meetingEtapeScatterColorForLabel'
src/core/application/get-org-dashboard-kpis.ts(52,5)
  'sellerUserId' does not exist in type ... Did you mean 'sellerUserIds'?
src/core/application/get-org-dashboard-kpis.ts(54,35)
  Property 'countMeetingsWithMeetingAtSinceAndOutcome' does not exist
src/core/application/get-org-dashboard-kpis.ts(63,40)
  Property 'listAnalysesForOrgMeetingsSince' does not exist
```

La commande, à lancer une seule fois, après avoir recopié le lot 75 :

```bash
git rm -f components/organisms/meeting-matrix-scatter.tsx \
          lib/meeting-outcome-badge-styles.ts \
          lib/meeting-outcome-config.ts \
          lib/meeting-outcome-labels.ts \
          src/core/application/get-org-dashboard-kpis.ts
```

Si `git rm` te dit qu'un fichier n'existe pas, c'est qu'il est déjà parti :
tant mieux, passe au suivant. C'est la liste complète, il n'y en a pas d'autres.

## 2. La séquence chez toi

```bash
# 1. recopier le contenu de sales-time/ par-dessus le dépôt
# 2. supprimer les cinq fichiers ci-dessus
npx prisma generate     # le client, que je ne peux pas produire ici
npm run verify          # typecheck + lint + tests
npm run build           # lance prisma migrate deploy puis next build
```

Les dépendances n'ont pas bougé : `package.json` et `package-lock.json` sont
identiques à ta base, donc pas de `npm install` obligatoire.

Attends d'avoir un `npm run build` vert en local avant de pousser. Un build qui
casse chez Vercel après que les migrations sont passées est plus pénible à
démêler que le même échec sur ta machine.

Puis :

```bash
git add -A && git commit && git push origin <branche de production>
```

La branche de production est celle que ton projet Vercel surveille, `main` ou
`master` selon ta configuration. C'est aussi celle sur laquelle tourne la CI
GitHub (lint, typecheck, tests), qui te donnera un deuxième avis gratuit.

## 3. Ce que Vercel fait tout seul

Ta commande de build est `prisma migrate deploy && next build`. Donc :

**Les deux migrations en attente passent automatiquement sur la base de
production.** Tu n'as rien à lancer à la main. `prisma.config.ts` choisit
`DIRECT_URL` (ou `DATABASE_URL_UNPOOLED`) et refuse explicitement de migrer à
travers le pooler Neon, qui bloquerait sur un verrou. Les deux variables sont
déjà déclarées dans le manifeste, pour `production` et `preview`.

Les deux migrations sont **additives** : une colonne `playbook` nullable sur
`OrganizationSettings`, et deux valeurs `SCORECARD` ajoutées à des enums. Si
jamais `next build` échouait après leur passage, la base serait en avance sur le
code, mais l'ancien code continuerait de tourner sans rien voir. Il n'y a donc
pas de retour en arrière à faire dans l'urgence.

Trois migrations précédentes ont déjà ajouté des valeurs d'enum exactement de la
même façon et sont passées. J'ai aussi vérifié que `schema.prisma` et les
fichiers de migration disent la même chose : pas de colonne déclarée dans le
schéma qui manquerait en base.

Les deux crons de `vercel.json` (purge RGPD à 3h, réconciliation des analyses à
4h) sont inchangés.

## 4. Ce qui n'est pas nécessaire, malgré les apparences

**Aucune nouvelle variable d'environnement.** J'ai diffé les 75 commits à la
recherche de tout nouveau `process.env` : il n'y en a aucun. Tes douze variables
suffisent.

**Pas besoin de retoucher tes prompts enregistrés en base.** La calibration
SONCAS et DISC du lot 75 s'ajoute au moment de l'appel, par-dessus le texte que
tu as sauvegardé dans l'écran d'administration. Tes prompts restent tels quels
et reçoivent l'échelle en plus.

**Pas de seed à lancer.** Le prompt SCORECARD se crée tout seul à sa première
utilisation. Et surtout, ne lance pas `npm run db:seed` en production : il
réinitialise le mot de passe du super admin.

**Ne touche pas à `AUTH_SESSION_VERSION`** sauf si tu veux déconnecter tout le
monde volontairement.

## 5. Quatre vérifications après le déploiement

**Le cron d'analyse répond.**

```bash
curl -s -H "Authorization: Bearer $CRON_SECRET" \
  https://<ton-domaine>/api/cron/process-analysis-jobs
```

Tu dois lire `{"ok":true,...}` et pas `{"error":"Unauthorized"}`.

**La nouvelle page playbook charge.** Ouvre `/company/settings/playbook`. C'est
la seule route ajoutée depuis ta base, et c'est elle qui lit la colonne créée
par la migration. Si elle s'affiche, la migration est passée.

**Une analyse SONCAS relancée montre la calibration.** Ouvre un rendez-vous,
relance l'analyse, et regarde les six leviers : ceux qui montent au-dessus de 19
doivent porter au moins une citation. Un levier haut sans citation voudrait dire
que la règle produit n'est pas appelée.

**Le classement d'équipe.** Il ne bougera pas tout de suite : la correction
s'applique à l'écriture, donc les analyses déjà en base gardent leurs notes. Ce
sont les nouvelles qui descendront, et les moyennes glisseront sur quelques
semaines. C'est voulu, mais c'est à dire à ton manager avant qu'il le découvre.

## 6. Après le déploiement

La sécurité, comme convenu. Quatre points relevés et volontairement laissés en
l'état jusqu'ici :

- les identifiants super admin par défaut dans `prisma/seed.ts` et
  `.env.example`
- une SSRF possible dans `lib/blob-access.ts`
- aucune limitation de débit sur l'authentification
- les sessions ne sont pas révoquées après une réinitialisation de mot de passe

Le quatrième est le plus gênant sur un produit destiné à la revente : quelqu'un
qui a volé une session la garde même après que la victime a changé son mot de
passe.
